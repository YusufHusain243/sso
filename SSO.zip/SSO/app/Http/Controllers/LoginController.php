<?php

namespace App\Http\Controllers;

use App\Models\Login;
use App\Http\Requests\StoreLoginRequest;
use App\Http\Requests\UpdateLoginRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class LoginController extends Controller
{
    public function index()
    {
        return view('login');
    }

    public function login(Request $request)
    {
        $request->validate([
            'username' => 'required',
            'password' => 'required'
        ]);
        $user = Login::where('username', $request->username)->first();
        if ($user && $user->verifyPassword($request->password)) {
            Auth::login($user);
            // dd('berhasil'); 
            dd(session()->all());
        } else {
            // Autentikasi gagal
            dd('gagal');
            // return redirect('/login')->withErrors('Gagal login. Silakan coba lagi.');
        }
    }

    public function logout()
    {
        Auth::logout();

        return redirect('/');
    }
}
