<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>LOGIN</h1>
    <form action="/login" method="post">
        <?php echo csrf_field(); ?>
        Username : <input type="text" name="username"><br>
        Password : <input type="text" name="password"><br>
        <button type="submit">LOGIN</button>
    </form>
</body>
</html><?php /**PATH C:\laragon\www\SSO\resources\views/login.blade.php ENDPATH**/ ?>